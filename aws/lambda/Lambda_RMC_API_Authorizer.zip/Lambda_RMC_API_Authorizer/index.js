// Imports
import { CognitoJwtVerifier } from 'aws-jwt-verify';

// Define globals
let pems;
const awsRegion = 'ap-southeast-2';
const cognitoUserPoolId = 'ap-southeast-2_HtB4MC4cO';
const iss = `https://cognito-idp.${awsRegion}.amazonaws.com/${cognitoUserPoolId}`;
const cognitoClientId = '56u2njrnvps7r2dcirvk6otjnl';
const apiBaseUrl = 'https://auth.malyaris.com/oauth2';
const apiEndpoints = {
	token: 'token',
};

// ============================================================
// REMOVE !!!!!!!!!!
const testToken = 'eyJraWQiOiIzOTZuQ281WGJHY0tqRGZzanNvZ0JyYldvaDVHN2lucVZWaEcreFRUbjRnPSIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiI3OWJiYjAxMi1hZTU1LTRlYzQtYWUzMi1hMDRiOWFhNDgwYTQiLCJpc3MiOiJodHRwczpcL1wvY29nbml0by1pZHAuYXAtc291dGhlYXN0LTIuYW1hem9uYXdzLmNvbVwvYXAtc291dGhlYXN0LTJfSHRCNE1DNGNPIiwidmVyc2lvbiI6MiwiY2xpZW50X2lkIjoiNTZ1Mm5qcm52cHM3cjJkY2lydms2b3RqbmwiLCJvcmlnaW5fanRpIjoiOWYxMTI2YjItM2ZjNC00M2UwLWIxZmQtNGRiOWJhYmJiNzUzIiwidG9rZW5fdXNlIjoiYWNjZXNzIiwic2NvcGUiOiJvcGVuaWQgZW1haWwiLCJhdXRoX3RpbWUiOjE2NzI4MTExMDEsImV4cCI6MTY3MjgxNDcwMSwiaWF0IjoxNjcyODExMTAyLCJqdGkiOiI4OWY5NjBjMS0xMGJjLTRmYWYtODk1Mi02MGI3MzgzYzI0M2YiLCJ1c2VybmFtZSI6Ijc5YmJiMDEyLWFlNTUtNGVjNC1hZTMyLWEwNGI5YWE0ODBhNCJ9.VcEaXsRXdPv-KoYPhLCi0j9a6zlMsRuT8M3L244o-Hhe-26voGAQkvDq71TFwkTmbIBgljdog6un6YKF3OU64r3Cs05VxOxnpx4dIbkzQEj4LDjEjUHPvdE5X1iMgZLoEOEECPkVad_g2CtxElKSwAWjmMVjP_re6jDUxmt1TMXCRo8Tezn5DBlC10cDI6xMCOz0D_Eb6IB0_0OOqVqxM89mnyGgYIB-IcapGulqt1SWyJf0aOAWNxx4zecYHLFVZxC3wrDExNDd8-BRKwBwR35ql10o5Lz5BrTJaa6ehiLFajx2IjoljspK1uvmpvMRuc46HxFH2ZJiZMTNr6To_w';
// ============================================================

export const handler = function (event, context, callback) {
	console.log('========== start ==========');
	// Get token from the header upon invocation - note this is an ACCESS token
	const token = testToken || event.authorizationToken;
	console.log('authorizationToken:', token);
	console.log(jwtTokenVerifier.verify(token));

	// try {
	//   const payload = await jwtTokenVerifier.verify(token);
	//   console.log("Token is valid. Payload:", payload);
	// } catch {
	//   console.log("Token not valid!");
	// }
	// console.log('decodedJWT', decodedJwt)

	// Acquire the PEMs for the user pool
	if (!pems) {
		// acquirePEMs();
	} else {
		// PEMs are already downloaded, continue with validating the token
		// ValidateToken(pems, event, context);
	}

	// Validate the JWT access token
	// validateToken(token);

	// Check it has the correct permissions

	// Generate the response
	switch (token) {
	case 'allow':
		callback(null, generatePolicy('user', 'Allow', event.methodArn));
		break;
	case 'deny':
		callback(null, generatePolicy('user', 'Deny', event.methodArn));
		break;
	case 'unauthorized':
		callback('Unauthorized'); // Return a 401 Unauthorized response
		break;
	default:
		callback('Error: Invalid token'); // Return a 500 Invalid token response
	}
	return context.logStreamName;
};

// Verifier that expects valid access tokens:
const jwtTokenVerifier = CognitoJwtVerifier.create({
	userPoolId: cognitoUserPoolId,
	tokenUse: 'access',
	clientId: cognitoClientId,
});

// Token validation
const validateToken = (token) => {
	let valid = true;
	console.log('==== validate token');
	valid = token.split('.').length === 3;

	return valid;
};

// Help function to generate an IAM policy
const generatePolicy = function (principalId, effect, resource) {
	const authResponse = {};

	authResponse.principalId = principalId;
	if (effect && resource) {
		const policyDocument = {};
		policyDocument.Version = '2012-10-17';
		policyDocument.Statement = [];
		const statementOne = {};
		statementOne.Action = 'execute-api:Invoke';
		statementOne.Effect = effect;
		statementOne.Resource = resource;
		policyDocument.Statement[0] = statementOne;
		authResponse.policyDocument = policyDocument;
	}

	// Optional output with custom properties of the String, Number or Boolean type.
	authResponse.context = {
		stringKey: 'stringval',
		numberKey: 123,
		booleanKey: true,
	};

	return authResponse;
};

// function ValidateToken(pems, event, context) {
//     var token = event.authorizationToken;

//     //Fail if the token is not jwt
//     var decodedJwt = jwt.decode(token, {complete: true});

//     if (!decodedJwt) {
//         console.log("Not a valid JWT token");
//         context.fail("Unauthorized");
//         return;
//     }

//     //Fail if token is not from your User Pool
//     if (decodedJwt.payload.iss != iss) {
//         console.log("invalid issuer");
//         context.fail("Unauthorized");
//         return;
//     }

//     //Reject the jwt if it's not an 'Access Token'
//     if (decodedJwt.payload.token_use != 'access') {
//         console.log("Not an access token");
//         context.fail("Unauthorized");
//         return;
//     }

//     // Get the kid from the token and retrieve corresponding PEM
//     var kid = decodedJwt.header.kid;
//     var pem = pems[kid];
//     if (!pem) {
//         console.log('Invalid access token');
//         context.fail("Unauthorized");
//         return;
//     }

//     // Verify the signature of the JWT token to ensure it's really coming from your User Pool
//     jwt.verify(token, pem, { issuer: iss }, function(err, payload) {
//       if (err) {
//         context.fail("Unauthorized");
//       } else {
//         // Valid token. Generate the API Gateway policy for the user
//         // Always generate the policy on value of 'sub' claim and not for
//		   // 'username' because username is reassignable sub is UUID for a
//         // user which is never reassigned to another user.
//         var principalId = payload.sub;

//         //Get AWS AccountId and API Options
//         var apiOptions = {};
//         var tmp = event.methodArn.split(':');
//         var apiGatewayArnTmp = tmp[5].split('/');
//         var awsAccountId = tmp[4];
//         apiOptions.region = tmp[3];
//         apiOptions.restApiId = apiGatewayArnTmp[0];
//         apiOptions.stage = apiGatewayArnTmp[1];
//         var method = apiGatewayArnTmp[2];
//         var resource = '/'; // root resource

//         if (apiGatewayArnTmp[3]) {
//             resource += apiGatewayArnTmp[3];
//         }

//         // For more information on specifics of generating policy, see the blueprint
//         // for the API Gateway custom authorizer in the Lambda console
//         // var policy = new AuthPolicy(principalId, awsAccountId, apiOptions);
//         // policy.allowAllMethods();

//         // context.succeed(policy.build());
//         console.log('===== success ======')
//       }
//     });
// };
